#pragma once

int LoadBitmap(const char *filename);